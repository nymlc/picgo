const fs = require('fs');
const path = require('path');
const child_process = require('child_process');

async function afterPack(appPath, appName) {

    const appDir = path.resolve(appPath); // 打包的应用所在目录
    const appBinaryPath = path.join(appDir, appName); // 原始应用可执行文件路径
    const renamedBinaryPath = path.join(appDir, `${appName}.bin`); // 重命名后的路径
    const scriptPath = path.join(appDir, appName); // 包装脚本路径

	console.log(appDir, appBinaryPath, renamedBinaryPath, scriptPath)
    console.log(`正在处理 Linux 包装脚本，应用路径: ${appBinaryPath}`);
    try {
        // 重命名原始可执行文件
        await new Promise((resolve, reject) => {
            child_process.exec(`mv "${appBinaryPath}" "${renamedBinaryPath}"`, (error) => {
                if (error) {
                    console.error('重命名原始可执行文件失败:', error);
                    return reject(error);
                }
                resolve();
            });
        });

        // 写入包装脚本
        const scriptContent = '#!/bin/bash\n' +
               '# 获取当前脚本的目录\n' +
               'SCRIPT_DIR="$(dirname "$(realpath "$0")")"\n' +
               '\n' +
               '# 使用脚本目录来运行 nymlc.bin\n' +
               '"${SCRIPT_DIR}/nymlc.bin" "$@" --no-sandbox';
        fs.writeFileSync(scriptPath, scriptContent, { mode: 0o755 }); // 添加可执行权限

        console.log('包装脚本已创建:', scriptPath);
    } catch (err) {
        console.error('处理包装脚本时发生错误:', err);
    }
}
module.exports = afterPack
