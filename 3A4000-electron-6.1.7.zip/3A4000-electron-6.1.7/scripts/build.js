var packager = require('electron-packager');
var installer = require('electron-installer-debian');
var path = require('path')
var fs = require('fs')
var os = require('os')
var moment = require('moment')
var pkg = require('../package.json')
var { setLinuxInstallShell,setLinuxRemoveShell } = require('./util');
var afterPack = require('./afterPack')

var packOptions = {
  arch: 'mips64el',
  dir: '.',
  name: pkg.name,
  overwrite: true,
  out: './release',
  // asar:false,
  asar: {
    unpackDir: 'node_modules/desktop-screenshot'
  },
  electronVersion: '6.1.7',
  electronZipDir: path.join(os.homedir(), './.cache/electron'),
  //   appCategoryType: 'public.app-category.productivity',
};

var installerOptions = {
  // src: './release/nymlc-linux-mips64el/',
  dest: './release/installers',
  arch: 'mips64el',
  ext: 'deb',
  icon: './resource/256x256.png',
  categories: ['Office'],
  rename: (dest, src) => {
    return path.join(dest, `<%= name %>_${moment().format('YYYY.MMDD.HHmm')}.<%= ext %>`)
  },
  scripts: {
    // 'pre': 'resources/pre_script', // 安装前执行的脚本
    'postinst': './scripts/shell/afterInstall.sh', // 安装后执行的脚本
    // 'preun': 'resources/preun_script', // preun：卸载前执行的脚本
    'postrm': './scripts/shell/afterRemove.sh' // postun：卸载后执行的脚本
  },
  description: pkg.description,
  version: pkg.version,
  productName: pkg.productName,
};
setLinuxInstallShell(packOptions.name)
setLinuxRemoveShell(packOptions.name)
packager(packOptions)
  .then(appPath => {
    console.log('pack success: ', appPath[0], '\n');
    installerOptions.src = appPath[0]
	afterPack(appPath[0], pkg.name).then(() => {
		fs.writeFileSync(appPath[0] + '/version', 'v' + packOptions.electronVersion, { encoding: 'utf8' })
		installer(installerOptions)
		  .then(() => {
		    console.log('build success!\n');
		  })
		  .catch(err => {
		    console.error(err);
		  });
	})

  })
  .catch(err => {
    console.error(err);
  });
