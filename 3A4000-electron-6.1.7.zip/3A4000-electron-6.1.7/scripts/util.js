/*
 * @Author: sq(qiusa@yixin.im)
 * @Date: 2023-08-25 10:23:08
 * @LastEditors: linchen@yixin.im
 * @LastEditTime: 2024-12-31 16:06:08
 * @Description: 打包通用方法
 */
const fs = require('fs');
const path = require('path');

//* 修改linux安装后的打包脚本 修改桌面快捷方式路径
function setLinuxInstallShell(name) {
  let content = fs.readFileSync(path.join(process.cwd(), './scripts/shell/afterInstall.txt'), 'utf-8');
  content = content.replace('$name_path', name);
  return fs.writeFileSync(path.join(process.cwd(), './scripts/shell/afterInstall.sh'), content, { mode: 0o755 });
}
//* 修改linux安装后的打包脚本 删除桌面图标
function setLinuxRemoveShell(name) {
  let content = fs.readFileSync(path.join(process.cwd(), './scripts/shell/afterRemove.txt'), 'utf-8');
  content = content.replace('$name_path', name);
  return fs.writeFileSync(path.join(process.cwd(), './scripts/shell/afterRemove.sh'), content, { mode: 0o755 });
}

module.exports = {
  setLinuxInstallShell,
  setLinuxRemoveShell,
};
