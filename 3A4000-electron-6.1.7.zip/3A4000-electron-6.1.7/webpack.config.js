const path = require('path');
const Dotenv = require('dotenv-webpack');

module.exports = {
    mode: 'production',//development,production
    devServer: {
        // contentBase: './dist',
    },
    target: 'electron-main', // 指定目标为 Electron 主进程
    entry: {
        'app': './src/app.ts',
        'preload': './src/preload.ts'
    },
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, 'dist'),
    },
    node: {
        __dirname: false,
        __filename: false,
    },
    resolve: {
        extensions: ['.tsx', '.ts', '.js', '.json'],
        alias: {
            '@': path.resolve(__dirname, 'src'),
        },
    },
    devtool: 'source-map',
    plugins: [new Dotenv({
      path: './scripts/env/.env', // 指定你自定义的.env文件路径
    })],
    optimization: {
        minimize: false, // 禁用代码压缩和混淆
    }, 
    externals: {
        'desktop-screenshot': 'commonjs desktop-screenshot',
        'ukey': 'commonjs ukey' // 将 ukey 标记为外部依赖
    },
    module: {
        rules: [
            {
                test: /\.ts$/,
                use: 'ts-loader',
                exclude: /node_modules/,  // 修改为不排除 get-folder-size
            },
        ],
    },
};